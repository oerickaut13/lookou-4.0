# Referências Bibliográficas

ADORNO, S.; PASINATO, W. . Violência e impunidade penal: Da criminalidade detectada à criminalidade investigada. Dilemas: **Revista de Estudos de Conflito e Controle Social**, v. 3, p. 51-84, 2010.
  
CAMÕES.  Instituto  da  Cooperação  e  da  Língua,  IP. Projeto  de  Apoio  ao  Ministério  do  Interior  de  Moçambique  –  Avaliação  a  Meio  Percurso. **Ministério  dos  Negócios  Estrangeiros.**  Maputo:  Gabinete  de  Avaliação e Auditoria, dez. 2013.

CASTRO, R. B.; PEDRO, R. M. Redes de vigilância: a experiência de segurança e da visibilidade articuladas às  câmeras  de  monitoramento  urbano.  **Anais  do  Simpósio  Vigilância,  Segurança  e  Controle  Social.** PUCPR, Curitiba/PR, Brasil, 4-6 mar. 2009, p. 70-91.

CHAPPELL, **Alisson. T. The philosophical versus actual adoption of community policing: a case study.** Criminal Justice Review, v. 34, n. 1, Mar. 2009.

FOUCAULT, Michel. **A sociedade punitiva: curso no Collège de France (1972-1973).** São Paulo: Martins Fontes, 2013.

KULA. **Criminalidade e vitimização**: cidades de Maputo, Beira e Nampula. Maputo: KULA, 2009.

LEDSOM, Alex. **Brasil é o 132º país mais seguro do mundo em 2023**; veja o top 10. Forbes, 30 jun. 2023. Disponível em: <https://forbes.com.br/forbeslife/2023/06/brasil-e-o-132o-pais-mais-seguro-do-mundo-em-2023-veja-o-top-10/#:~:text=O%20%C3%8Dndice%20Global%20da%20Paz,2022%2C%20com%20impacto%20no%20turismo&text=A%20Isl%C3%A2ndia%20continua%20sendo%20o,posi%C3%A7%C3%A3o%20%E2%80%93%20163%20pa%C3%ADses%20s%C3%A3o%20avaliados>. Acesso em: 24 ago. 2024.

OBERWEIS, Trish; MUSHENO, Michael. **Knowing rights: state actors’ stories of power, identity and morality.** Aldershot: Dartmouth, 2001.

RUBIN, Kenneth S. **Essential Scrum: A Practical Guide to the Most Popular Agile Process.** Upper Saddle River, NJ: Addison-Wesley, 2017.

SCHWABER, Ken; SUTHERLAND, Jeff. The **Scrum Guide: The Definitive Guide to Scrum: The Rules of the Game.** 2020. Disponível em: https://scrumguides.org/. Acesso em: 21/09/2024.

