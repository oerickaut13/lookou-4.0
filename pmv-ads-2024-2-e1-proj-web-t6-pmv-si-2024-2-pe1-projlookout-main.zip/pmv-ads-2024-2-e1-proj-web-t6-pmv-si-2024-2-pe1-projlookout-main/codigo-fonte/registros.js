// Função para alternar a exibição do menu
function toggleMenu() {
    const menu = document.getElementById('menu');
    menu.classList.toggle('active');
}
